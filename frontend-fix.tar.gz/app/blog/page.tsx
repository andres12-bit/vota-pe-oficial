'use client';

import { useState } from 'react';
import Link from 'next/link';
import NavHeader from '@/components/NavHeader';
import SiteFooter from '@/components/SiteFooter';

interface Article {
    id: string;
    title: string;
    date: string;
    tag: string;
    tagColor: string;
    summary: string;
    content: string;
    source: string;
    icon: string;
    readTime: string;
    image?: string;
}

const ARTICLES: Article[] = [
    {
        id: 'encuestas-presidenciales-2026',
        title: '¿Quiénes lideran las encuestas presidenciales 2026?',
        date: 'Marzo 2026',
        tag: 'Análisis',
        tagColor: '#c62828',
        icon: '📊',
        readTime: '5 min',
        summary: 'Según las últimas encuestas de Ipsos y Datum, César Acuña (APP), Keiko Fujimori (Fuerza Popular) y Rafael López Aliaga (Renovación Popular) lideran la intención de voto.',
        content: 'Según las últimas encuestas de Ipsos y Datum, César Acuña (APP), Keiko Fujimori (Fuerza Popular) y Rafael López Aliaga (Renovación Popular) lideran la intención de voto. El margen entre los tres primeros es menor a 5 puntos porcentuales, anticipando una segunda vuelta muy reñida.\n\nLas encuestas muestran que el electorado peruano se encuentra fragmentado entre más de 20 candidaturas presidenciales activas. La volatilidad del voto sigue siendo alta, con un 35% de electores que aún no define su voto, lo que convierte a las últimas semanas de campaña en un periodo decisivo.\n\nLa brecha entre los tres primeros candidatos se ha reducido significativamente en comparación con encuestas de enero, cuando Acuña lideraba con más de 8 puntos de ventaja. Analistas coinciden en que la segunda vuelta será inevitable y que las alianzas de última hora podrían definir al ganador.',
        source: 'Fuente: Ipsos Perú, Datum Internacional (Marzo 2026)',
    },
    {
        id: 'bicameralidad-2026',
        title: 'La nueva bicameralidad: ¿qué cambia para el elector?',
        date: 'Marzo 2026',
        tag: 'Educativo',
        tagColor: '#1565c0',
        icon: '🏛️',
        readTime: '7 min',
        summary: 'Con la restitución del Senado aprobada por votación congresal (Ley 31988), los peruanos elegirán por primera vez en décadas tanto senadores como diputados.',
        content: 'Con la restitución del Senado aprobada por votación congresal (Ley 31988), los peruanos elegirán por primera vez en décadas tanto senadores como diputados. El Senado tendrá 60 escaños con distrito nacional único, mientras que los 130 diputados se elegirán por distrito electoral múltiple regional.\n\nEste cambio histórico busca mejorar la calidad legislativa mediante una cámara de revisión que filtre las leyes aprobadas por la Cámara de Diputados. El Senado no podrá originar leyes de presupuesto y tendrá funciones especiales como la ratificación de embajadores y magistrados.\n\nPara el elector, esto significa que ahora tendrá 3 cédulas de votación: una para presidente, una para senadores (lista nacional) y otra para diputados (lista regional). Es importante informarse sobre los candidatos en las tres instancias ya que cada cargo cumple funciones distintas.',
        source: 'Fuente: Ley 31988 — Reforma Constitucional de Bicameralidad (aprobada por el Congreso)',
    },
    {
        id: 'comparativa-planes-gobierno',
        title: 'Comparativa de planes de gobierno económicos',
        date: 'Febrero 2026',
        tag: 'Propuestas',
        tagColor: '#ca8a04',
        icon: '💰',
        readTime: '8 min',
        summary: 'Los planes de gobierno presentan diferencias marcadas en política tributaria, minería y gasto social.',
        content: 'Los planes de gobierno de los candidatos presidenciales presentan diferencias marcadas en política tributaria, minería y gasto social. APP propone reducir el IGV al 15%, Fuerza Popular plantea zonas económicas especiales, y Renovación Popular impulsa la inversión privada en infraestructura.\n\nEn materia tributaria, las propuestas van desde la reducción del IGV (APP) hasta la creación de nuevos impuestos a las grandes fortunas (partidos de izquierda). En minería, la mayoría de candidatos propone un marco más favorable a la inversión, mientras que algunos plantean la revisión de contratos existentes.\n\nEl gasto social también muestra diferencias. Mientras unos candidatos priorizan la expansión de programas como Pensión 65 y Qali Warma, otros proponen reformarlos completamente bajo esquemas de emprendimiento y formalización.',
        source: 'Fuente: Planes de Gobierno registrados en el JNE (Infogob)',
    },
    {
        id: 'perfil-candidatos-senado',
        title: 'El perfil de los candidatos al nuevo Senado',
        date: 'Febrero 2026',
        tag: 'Perfiles',
        tagColor: '#7c3aed',
        icon: '📋',
        readTime: '6 min',
        summary: 'De los más de 700 candidatos al Senado, el 43% cuenta con estudios de posgrado y el 28% tiene experiencia previa.',
        content: 'De los más de 700 candidatos al Senado, el 43% cuenta con estudios de posgrado, el 28% tiene experiencia previa en el Congreso, y el promedio de edad es de 52 años. Lima concentra el 35% de los candidatos, seguida por Arequipa (8%) y La Libertad (7%).\n\nEl análisis por partido revela que los partidos tradicionales tienen un mayor porcentaje de candidatos con experiencia legislativa, mientras que los nuevos movimientos políticos presentan candidatos más jóvenes pero con menor experiencia pública.\n\nEn cuanto a paridad de género, solo el 38% de los candidatos al Senado son mujeres, a pesar de la ley de paridad aprobada en 2020. Las listas que más se acercan a la paridad son las de partidos de centro-izquierda.',
        source: 'Fuente: Hojas de Vida del JNE — Infogob',
    },
    {
        id: 'voto-electronico-2026',
        title: '¿Habrá voto electrónico en las elecciones 2026?',
        date: 'Marzo 2026',
        tag: 'Educativo',
        tagColor: '#1565c0',
        icon: '🗳️',
        readTime: '4 min',
        summary: 'La ONPE ha confirmado que el voto electrónico presencial se implementará en más de 60 distritos del país para las elecciones 2026.',
        content: 'La ONPE ha confirmado que el voto electrónico presencial se implementará en más de 60 distritos del país para las elecciones 2026, ampliando significativamente el piloto de 2022 que cubrió solo 15 distritos.\n\nEl sistema de voto electrónico peruano utiliza una tablet con pantalla táctil donde el elector selecciona su candidato y confirma su voto. El sistema imprime un comprobante que se deposita en un ánfora física como respaldo.\n\nLa ONPE ha realizado más de 200 simulacros a nivel nacional para familiarizar a los electores con el nuevo sistema. Se estima que 2.5 millones de electores usarán voto electrónico, mientras que el resto del país continuará con el sistema manual tradicional.',
        source: 'Fuente: ONPE — Oficina Nacional de Procesos Electorales',
    },
    {
        id: 'financiamiento-campanas-2026',
        title: 'Financiamiento de campañas: ¿de dónde viene el dinero?',
        date: 'Febrero 2026',
        tag: 'Investigación',
        tagColor: '#e65100',
        icon: '🔍',
        readTime: '9 min',
        summary: 'El financiamiento de campañas electorales en Perú sigue siendo uno de los temas más opacos del proceso democrático.',
        content: 'El financiamiento de campañas electorales en Perú sigue siendo uno de los temas más opacos del proceso democrático. Según datos de la ONPE, los 36 partidos que presentan candidatos presidenciales han declarado ingresos combinados de más de S/. 180 millones para la campaña 2026.\n\nSin embargo, organismos de vigilancia como Transparencia estiman que el gasto real supera ampliamente lo declarado. La Ley de Organizaciones Políticas obliga a declarar donaciones mayores a 1 UIT y prohíbe aportes de origen anónimo, pero la fiscalización en tiempo real sigue siendo limitada.\n\nPulsoElectoral.pe ha analizado las declaraciones de ingresos y gastos de los principales candidatos, encontrando que 5 de los 10 primeros en encuestas han recibido aportes de grupos económicos vinculados a sectores regulados como minería, construcción y banca.',
        source: 'Fuente: ONPE, Transparencia — Informes de Financiamiento de Campañas',
    },
    {
        id: 'debate-presidencial-2026',
        title: 'Primer debate presidencial: los momentos clave',
        date: 'Marzo 2026',
        tag: 'Análisis',
        tagColor: '#c62828',
        icon: '🎤',
        readTime: '6 min',
        summary: 'El primer debate presidencial organizado por el JNE dejó momentos tensos y propuestas concretas que los electores deben conocer.',
        content: 'El primer debate presidencial organizado por el JNE dejó momentos tensos y propuestas concretas que los electores deben conocer. Participaron los 10 candidatos con mayor intención de voto según las encuestas.\n\nLos temas centrales fueron: seguridad ciudadana, economía, educación y lucha contra la corrupción. Los candidatos tuvieron 3 minutos por bloque para presentar sus propuestas y 1 minuto para réplicas.\n\nLos analistas políticos coinciden en que los candidatos con mejor desempeño fueron aquellos que presentaron cifras concretas y metas medibles, mientras que los que recurrieron a generalidades y ataques personales fueron los peor evaluados por los paneles de expertos.',
        source: 'Fuente: JNE — Debate Presidencial 2026',
    },
    {
        id: 'candidatas-mujeres-2026',
        title: 'Candidatas mujeres 2026: ¿avanza la paridad?',
        date: 'Febrero 2026',
        tag: 'Perfiles',
        tagColor: '#7c3aed',
        icon: '👩‍💼',
        readTime: '5 min',
        summary: 'Las elecciones 2026 son las primeras bajo la ley de paridad y alternancia. ¿Se está cumpliendo el mandato legal?',
        content: 'Las elecciones 2026 son las primeras bajo la ley de paridad y alternancia aprobada en 2020. Según el análisis de PulsoElectoral.pe, el 47% de los candidatos a diputados son mujeres, mientras que para el Senado la cifra baja al 38%.\n\nLa ley establece que las listas deben tener 50% de candidatos de cada sexo, con alternancia obligatoria. Sin embargo, algunos partidos han colocado a las candidatas mujeres en posiciones menos competitivas de la lista.\n\nEn la carrera presidencial, solo 5 de los 36 candidatos son mujeres, siendo Keiko Fujimori (Fuerza Popular) la que lidera las encuestas entre las candidatas femeninas. Otras candidatas destacadas incluyen representantes de partidos emergentes que proponen agendas específicas de género.',
        source: 'Fuente: JNE — Análisis de listas electorales 2026',
    },
];

const CATEGORIES = ['Todos', 'Análisis', 'Educativo', 'Propuestas', 'Perfiles', 'Investigación'];

export default function BlogPage() {
    const [selectedCategory, setSelectedCategory] = useState('Todos');
    const [expandedArticle, setExpandedArticle] = useState<string | null>(null);

    const filtered = selectedCategory === 'Todos'
        ? ARTICLES
        : ARTICLES.filter(a => a.tag === selectedCategory);

    return (
        <>
            <NavHeader />
            <div className="blog-page">
                {/* Hero */}
                <div className="blog-hero">
                    <div className="blog-hero-content">
                        <span className="blog-hero-badge">📰 Noticias Electorales</span>
                        <h1 className="blog-hero-title">Blog Electoral</h1>
                        <p className="blog-hero-subtitle">
                            Análisis, tendencias y noticias sobre las elecciones generales del Perú 2026.
                            Información basada en fuentes oficiales para tu decisión informada.
                        </p>
                        <div className="blog-hero-stats">
                            <div className="blog-hero-stat">
                                <span className="stat-value">{ARTICLES.length}</span>
                                <span className="stat-label">Artículos</span>
                            </div>
                            <div className="blog-hero-stat">
                                <span className="stat-value">{CATEGORIES.length - 1}</span>
                                <span className="stat-label">Categorías</span>
                            </div>
                            <div className="blog-hero-stat">
                                <span className="stat-value">Diario</span>
                                <span className="stat-label">Actualización</span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Category filters */}
                <div className="blog-filters-container">
                    <div className="blog-filters">
                        {CATEGORIES.map(cat => (
                            <button
                                key={cat}
                                className={`blog-filter-btn ${selectedCategory === cat ? 'blog-filter-active' : ''}`}
                                onClick={() => setSelectedCategory(cat)}
                            >
                                {cat}
                            </button>
                        ))}
                    </div>
                </div>

                {/* Articles grid */}
                <div className="blog-content">
                    <div className="blog-grid">
                        {filtered.map(article => (
                            <article key={article.id} className="blog-card">
                                <div className="blog-card-header">
                                    <span className="blog-card-icon">{article.icon}</span>
                                    <div className="blog-card-meta">
                                        <span className="blog-card-tag" style={{ background: article.tagColor }}>{article.tag}</span>
                                        <span className="blog-card-date">{article.date}</span>
                                    </div>
                                </div>
                                <h2 className="blog-card-title">{article.title}</h2>
                                <p className="blog-card-summary">{article.summary}</p>

                                {expandedArticle === article.id ? (
                                    <div className="blog-card-expanded">
                                        {article.content.split('\n\n').map((p, i) => (
                                            <p key={i} className="blog-card-paragraph">{p}</p>
                                        ))}
                                        <button
                                            className="blog-card-toggle"
                                            onClick={() => setExpandedArticle(null)}
                                        >
                                            Cerrar ↑
                                        </button>
                                    </div>
                                ) : (
                                    <button
                                        className="blog-card-toggle"
                                        onClick={() => setExpandedArticle(article.id)}
                                    >
                                        Leer más →
                                    </button>
                                )}

                                <div className="blog-card-footer">
                                    <span className="blog-card-source">{article.source}</span>
                                    <span className="blog-card-readtime">⏱ {article.readTime}</span>
                                </div>
                            </article>
                        ))}
                    </div>
                </div>
            </div>
            <SiteFooter />
        </>
    );
}
